"""
Quick start example for CP-BO optimization.
"""

import numpy as np
from cpbo import CPBO
from cpbo.constraints import LinearConstraint

def simple_objective(config):
    """Minimize: (x - 2)^2 + (y + 1)^2"""
    x = config['x']
    y = config['y']
    return (x - 2)**2 + (y + 1)**2

def main():
    print("="*60)
    print("CP-BO Quick Start Example")
    print("="*60)
    
    # Define hyperparameter space
    space = {
        'x': (-5.0, 5.0, 'continuous'),
        'y': (-5.0, 5.0, 'continuous')
    }
    
    # Define constraints
    constraints = [
        LinearConstraint('x + y <= 3'),
        LinearConstraint('x >= -2')
    ]
    
    # Initialize optimizer
    optimizer = CPBO(
        objective_function=simple_objective,
        space=space,
        constraints=constraints,
        n_iterations=50,
        n_initial=10,
        random_state=42,
        verbose=True
    )
    
    # Run optimization
    best_config = optimizer.optimize()
    
    # Display results
    print(f"\nBest configuration:")
    print(f"  x = {best_config['x']:.4f}")
    print(f"  y = {best_config['y']:.4f}")
    print(f"Best value: {optimizer.best_value_:.4f}")

if __name__ == '__main__':
    main()
