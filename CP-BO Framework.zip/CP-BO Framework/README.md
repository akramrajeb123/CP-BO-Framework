# CP-BO: Hybrid Constraint Programming and Bayesian Optimization

A powerful framework combining Constraint Programming (CP) and Bayesian Optimization (BO) for hyperparameter optimization with complex constraints.

## Features

- 🎯 **Hybrid Optimization**: Combines CP for constraint handling with BO for efficient search
- 🔒 **Rich Constraints**: Support for linear, logical, fairness, and resource constraints
- 🚀 **Efficient Search**: Space decomposition and constraint-aware acquisition
- 📊 **Easy to Use**: Simple API with comprehensive examples
- 🧪 **Well Tested**: Extensive unit tests and real-world examples

## Installation

```bash
pip install -r requirements.txt
pip install -e .
```

## Quick Start

```python
from cpbo import CPBO
from cpbo.constraints import LinearConstraint

# Define objective
def objective(config):
    return (config['x'] - 2)**2 + (config['y'] + 1)**2

# Define space and constraints
space = {
    'x': (-5.0, 5.0, 'continuous'),
    'y': (-5.0, 5.0, 'continuous')
}

constraints = [LinearConstraint('x + y <= 3')]

# Optimize
optimizer = CPBO(objective, space, constraints, n_iterations=50)
best_config = optimizer.optimize()
```

## Documentation

See [examples/](examples/) for more detailed examples including:
- XGBoost with fairness constraints
- Neural network architecture search
- Resource-constrained optimization


