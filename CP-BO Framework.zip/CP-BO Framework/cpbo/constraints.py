"""
Constraint definitions for hyperparameter optimization.
"""

import numpy as np
from abc import ABC, abstractmethod
from typing import Dict

class Constraint(ABC):
    """Base class for constraints."""
    
    @abstractmethod
    def is_satisfied(self, config: Dict) -> bool:
        """Check if configuration satisfies the constraint."""
        pass

class LinearConstraint(Constraint):
    """
    Linear constraint on hyperparameters.
    
    Examples
    --------
    >>> constraint = LinearConstraint('x + 2*y <= 5')
    >>> config = {'x': 1.0, 'y': 2.0}
    >>> constraint.is_satisfied(config)
    True
    """
    
    def __init__(self, expression: str):
        self.expression = expression
        self.parsed = self._parse_expression(expression)
    
    def _parse_expression(self, expr: str) -> Dict:
        """Parse linear constraint expression."""
        if '<=' in expr:
            op, lhs, rhs = '<=', *expr.split('<=')
        elif '>=' in expr:
            op, lhs, rhs = '>=', *expr.split('>=')
        elif '<' in expr:
            op, lhs, rhs = '<', *expr.split('<')
        elif '>' in expr:
            op, lhs, rhs = '>', *expr.split('>')
        elif '==' in expr:
            op, lhs, rhs = '==', *expr.split('==')
        else:
            raise ValueError(f"Invalid constraint: {expr}")
        
        return {'lhs': lhs.strip(), 'op': op, 'rhs': float(rhs.strip())}
    
    def is_satisfied(self, config: Dict) -> bool:
        """Check if configuration satisfies constraint."""
        try:
            lhs_value = self._evaluate_lhs(config)
            rhs_value = self.parsed['rhs']
            op = self.parsed['op']
            
            if op == '<=': return lhs_value <= rhs_value
            elif op == '>=': return lhs_value >= rhs_value
            elif op == '<': return lhs_value < rhs_value
            elif op == '>': return lhs_value > rhs_value
            elif op == '==': return abs(lhs_value - rhs_value) < 1e-6
        except:
            return False
    
    def _evaluate_lhs(self, config: Dict) -> float:
        """Evaluate left-hand side expression."""
        lhs = self.parsed['lhs']
        for param_name, value in config.items():
            lhs = lhs.replace(param_name, str(value))
        return eval(lhs)

class FairnessConstraint(Constraint):
    """
    Demographic parity fairness constraint.
    
    Parameters
    ----------
    protected_attribute : str
        Name of protected attribute.
    max_disparity : float
        Maximum allowed disparity.
    """
    
    def __init__(self, protected_attribute: str, max_disparity: float = 0.05):
        self.protected_attribute = protected_attribute
        self.max_disparity = max_disparity
    
    def is_satisfied(self, config: Dict) -> bool:
        return True  # Evaluated during model training
    
    def compute_disparity(self, y_pred: np.ndarray, 
                         sensitive: np.ndarray) -> float:
        """Compute demographic parity disparity."""
        mask_0 = (sensitive == 0)
        mask_1 = (sensitive == 1)
        
        rate_0 = np.mean(y_pred[mask_0]) if mask_0.sum() > 0 else 0.0
        rate_1 = np.mean(y_pred[mask_1]) if mask_1.sum() > 0 else 0.0
        
        return abs(rate_0 - rate_1)
