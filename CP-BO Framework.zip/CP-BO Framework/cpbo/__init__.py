"""
CP-BO: Hybrid Constraint Programming and Bayesian Optimization
================================================================

A framework for hyperparameter optimization combining constraint 
programming and Bayesian optimization.
"""

__version__ = '0.1.0'
__author__ = 'Akram-Rajeb'

from .optimizer import CPBO
from .constraints import (
    Constraint,
    LinearConstraint,
    LogicalConstraint,
    FairnessConstraint
)
from .space import HyperparameterSpace

__all__ = [
    'CPBO',
    'Constraint',
    'LinearConstraint',
    'LogicalConstraint',
    'FairnessConstraint',
    'HyperparameterSpace',
]
