"""
Hyperparameter space definition and utilities.
"""

import numpy as np
from typing import Dict, Any

class HyperparameterSpace:
    """
    Defines the hyperparameter search space.
    
    Parameters
    ----------
    space_dict : Dict
        Dictionary defining the space. Format:
        {
            'param_name': (lower, upper, 'continuous'),
            'param_name': (lower, upper, 'integer'),
            'param_name': ([val1, val2, ...], 'categorical')
        }
    """
    
    def __init__(self, space_dict: Dict):
        self.space_dict = space_dict
        self.params = {}
        self.param_names = []
        
        for param_name, param_def in space_dict.items():
            param_type = param_def[2]
            
            if param_type == 'continuous':
                self.params[param_name] = {
                    'type': 'continuous',
                    'bounds': (float(param_def[0]), float(param_def[1]))
                }
            elif param_type == 'integer':
                self.params[param_name] = {
                    'type': 'integer',
                    'bounds': (int(param_def[0]), int(param_def[1]))
                }
            elif param_type == 'categorical':
                self.params[param_name] = {
                    'type': 'categorical',
                    'values': list(param_def[0])
                }
            
            self.param_names.append(param_name)
    
    def sample(self) -> Dict:
        """Sample a random configuration from the space."""
        config = {}
        for param_name in self.param_names:
            config[param_name] = self.sample_param(param_name)
        return config
    
    def sample_param(self, param_name: str) -> Any:
        """Sample a single parameter."""
        param_info = self.params[param_name]
        
        if param_info['type'] == 'continuous':
            return np.random.uniform(param_info['bounds'][0], 
                                    param_info['bounds'][1])
        elif param_info['type'] == 'integer':
            return np.random.randint(param_info['bounds'][0], 
                                    param_info['bounds'][1] + 1)
        elif param_info['type'] == 'categorical':
            return np.random.choice(param_info['values'])
    
    def config_to_array(self, config: Dict) -> np.ndarray:
        """Convert configuration dict to array representation."""
        x = []
        for param_name in self.param_names:
            param_info = self.params[param_name]
            value = config[param_name]
            
            if param_info['type'] in ['continuous', 'integer']:
                x.append(float(value))
            elif param_info['type'] == 'categorical':
                idx = param_info['values'].index(value)
                one_hot = [0.0] * len(param_info['values'])
                one_hot[idx] = 1.0
                x.extend(one_hot)
        
        return np.array(x)
