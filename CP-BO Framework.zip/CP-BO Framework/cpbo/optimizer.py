"""
Main CP-BO optimizer implementation.
"""

import numpy as np
from typing import Dict, List, Callable, Optional, Any
from tqdm import tqdm

from .cp_solver import CPSolver
from .bo_surrogate import BayesianOptimizer
from .acquisition import ConstraintAwareAcquisition
from .space import HyperparameterSpace
from .constraints import Constraint

class CPBO:
    """
    Hybrid Constraint Programming and Bayesian Optimization.
    
    Parameters
    ----------
    objective_function : Callable
        Function to optimize.
    space : Dict or HyperparameterSpace
        Hyperparameter space definition.
    constraints : List[Constraint]
        List of constraints to satisfy.
    n_iterations : int, default=100
        Number of optimization iterations.
    n_initial : int, default=10
        Number of random initialization points.
    """
    
    def __init__(
        self,
        objective_function: Callable[[Dict], float],
        space: Dict,
        constraints: List[Constraint] = None,
        n_iterations: int = 100,
        n_initial: int = 10,
        kernel: str = 'matern52',
        acquisition: str = 'ei',
        n_regions: int = 5,
        random_state: Optional[int] = None,
        verbose: bool = True
    ):
        self.objective_function = objective_function
        self.constraints = constraints or []
        self.n_iterations = n_iterations
        self.n_initial = n_initial
        self.verbose = verbose
        
        if random_state is not None:
            np.random.seed(random_state)
        
        # Initialize space
        if isinstance(space, dict):
            self.space = HyperparameterSpace(space)
        else:
            self.space = space
        
        # Initialize components
        self.cp_solver = CPSolver(self.space, self.constraints)
        self.bo_optimizer = None
        
        # Results
        self.best_config_ = None
        self.best_value_ = float('inf')
        self.history_ = []
    
    def optimize(self) -> Dict:
        """Run the CP-BO optimization."""
        # Phase 1: Initial sampling
        if self.verbose:
            print(f"Phase 1: Sampling {self.n_initial} initial points...")
        
        for _ in range(self.n_initial):
            config = self._sample_feasible()
            self._evaluate(config)
        
        # Phase 2: Bayesian optimization
        if self.verbose:
            print(f"Phase 2: Bayesian optimization...")
        
        for iteration in range(self.n_initial, self.n_iterations):
            # Update surrogate
            X = np.array([self.space.config_to_array(h['config']) 
                         for h in self.history_])
            y = np.array([h['value'] for h in self.history_])
            
            # Get next configuration
            next_config = self._get_next_config(X, y)
            self._evaluate(next_config)
        
        return self.best_config_
